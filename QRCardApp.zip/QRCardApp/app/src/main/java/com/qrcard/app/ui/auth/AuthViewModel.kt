package com.qrcard.app.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrcard.app.data.repository.AuthRepository
import kotlinx.coroutines.launch

class AuthViewModel : ViewModel() {
    
    private val repository = AuthRepository()
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage
    
    private val _isAuthenticated = MutableLiveData<Boolean>()
    val isAuthenticated: LiveData<Boolean> = _isAuthenticated
    
    init {
        // Check if user is already authenticated
        _isAuthenticated.value = repository.currentUser != null
    }
    
    fun login(email: String, password: String) {
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                repository.login(email, password)
                _isAuthenticated.value = true
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Login failed"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun register(
        fullName: String,
        email: String,
        password: String,
        phoneNumber: String,
        city: String,
        referralCode: String = ""
    ) {
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                repository.register(fullName, email, password, phoneNumber, city, referralCode)
                _isAuthenticated.value = true
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Registration failed"
            } finally {
                _isLoading.value = false
            }
        }
    }
}
