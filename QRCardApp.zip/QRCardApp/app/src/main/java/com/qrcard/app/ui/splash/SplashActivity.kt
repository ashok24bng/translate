package com.qrcard.app.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.qrcard.app.R
import com.qrcard.app.ui.auth.AuthActivity
import com.qrcard.app.ui.main.MainActivity

class SplashActivity : AppCompatActivity() {
    
    private val auth = FirebaseAuth.getInstance()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        
        // Delay for 2 seconds then check authentication state
        Handler(Looper.getMainLooper()).postDelayed({
            checkAuthState()
        }, 2000)
    }
    
    private fun checkAuthState() {
        if (auth.currentUser != null) {
            // User is logged in, navigate to MainActivity
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            // User is not logged in, navigate to AuthActivity
            startActivity(Intent(this, AuthActivity::class.java))
        }
        
        // Finish this activity
        finish()
    }
}
