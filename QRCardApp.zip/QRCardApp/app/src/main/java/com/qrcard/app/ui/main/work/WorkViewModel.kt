package com.qrcard.app.ui.main.work

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.qrcard.app.data.model.QRCode
import com.qrcard.app.data.model.User
import com.qrcard.app.data.repository.QRCodeRepository
import com.qrcard.app.data.repository.UserRepository
import kotlinx.coroutines.launch

class WorkViewModel : ViewModel() {
    
    private val qrCodeRepository = QRCodeRepository()
    private val userRepository = UserRepository()
    private val auth = FirebaseAuth.getInstance()
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage
    
    private val _qrCodeGenerated = MutableLiveData<QRCode?>()
    val qrCodeGenerated: LiveData<QRCode?> = _qrCodeGenerated
    
    private val _dailyQRCount = MutableLiveData<Int>()
    val dailyQRCount: LiveData<Int> = _dailyQRCount
    
    private val _dailyLimit = MutableLiveData<Int>()
    val dailyLimit: LiveData<Int> = _dailyLimit
    
    init {
        loadUserData()
        loadDailyQRCount()
    }
    
    private fun loadUserData() {
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                val user = userRepository.getUserData()
                _dailyLimit.value = user.plan.dailyLimit
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to load user data"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    private fun loadDailyQRCount() {
        val userId = auth.currentUser?.uid ?: return
        
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                val count = qrCodeRepository.getTodayQRCodesCount(userId)
                _dailyQRCount.value = count
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to load QR code count"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun generateQRCode(
        companyName: String,
        city: String,
        country: String,
        zipCode: String,
        businessId: String
    ) {
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                val qrCode = qrCodeRepository.generateQRCode(
                    companyName,
                    city,
                    country,
                    zipCode,
                    businessId
                )
                
                _qrCodeGenerated.value = qrCode
                
                // Update daily count
                loadDailyQRCount()
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to generate QR code"
            } finally {
                _isLoading.value = false
                _qrCodeGenerated.value = null // Reset to prevent showing the dialog again on rotation
            }
        }
    }
}
