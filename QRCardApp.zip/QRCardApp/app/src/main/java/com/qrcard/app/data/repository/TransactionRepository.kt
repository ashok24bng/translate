package com.qrcard.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.qrcard.app.data.model.Transaction
import com.qrcard.app.data.model.User
import kotlinx.coroutines.tasks.await

class TransactionRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    
    suspend fun getTransactionHistory(userId: String, limit: Long = 50): List<Transaction> {
        val query = firestore.collection("transactions")
            .whereEqualTo("userId", userId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
        
        return query.documents.mapNotNull { it.toObject(Transaction::class.java) }
    }
    
    suspend fun requestWithdrawal(amount: Double, bankDetails: Map<String, String>): Transaction {
        val userId = auth.currentUser?.uid ?: throw Exception("User not logged in")
        
        // Get user data to check balance
        val userDoc = firestore.collection("users").document(userId).get().await()
        val user = userDoc.toObject(User::class.java) ?: throw Exception("User data not found")
        
        // Check if user has sufficient balance
        if (user.wallet.balance < amount) {
            throw Exception("Insufficient balance")
        }
        
        // Check minimum withdrawal amount
        if (amount < 100) {
            throw Exception("Minimum withdrawal amount is ₹100")
        }
        
        // Create transaction
        val transaction = Transaction(
            userId = userId,
            amount = amount,
            type = "withdrawal",
            status = "pending",
            description = "Withdrawal request",
            paymentDetails = bankDetails
        )
        
        // Add to Firestore
        val docRef = firestore.collection("transactions").add(transaction).await()
        
        // Update user wallet
        firestore.collection("users").document(userId)
            .update("wallet.balance", com.google.firebase.firestore.FieldValue.increment(-amount))
            .await()
        
        return transaction.copy(id = docRef.id)
    }
    
    suspend fun updateBankDetails(bankDetails: Map<String, String>): Boolean {
        val userId = auth.currentUser?.uid ?: throw Exception("User not logged in")
        
        firestore.collection("users").document(userId)
            .update("bankDetails", bankDetails)
            .await()
        
        return true
    }
}
