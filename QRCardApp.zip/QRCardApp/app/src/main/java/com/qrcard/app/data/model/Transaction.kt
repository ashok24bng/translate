package com.qrcard.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName
import java.util.Date

data class Transaction(
    @DocumentId
    val id: String = "",
    
    @PropertyName("userId")
    val userId: String = "",
    
    @PropertyName("amount")
    val amount: Double = 0.0,
    
    @PropertyName("type")
    val type: String = "",
    
    @PropertyName("status")
    val status: String = "",
    
    @PropertyName("description")
    val description: String = "",
    
    @PropertyName("timestamp")
    val timestamp: Timestamp = Timestamp.now(),
    
    @PropertyName("paymentDetails")
    val paymentDetails: Map<String, Any>? = null
) {
    fun getFormattedDate(): String {
        val date = timestamp.toDate()
        return android.text.format.DateFormat.format("dd MMM yyyy, hh:mm a", date).toString()
    }
}
