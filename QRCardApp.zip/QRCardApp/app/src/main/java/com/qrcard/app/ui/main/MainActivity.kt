package com.qrcard.app.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.qrcard.app.R
import com.qrcard.app.databinding.ActivityMainBinding
import com.qrcard.app.ui.main.dashboard.DashboardFragment
import com.qrcard.app.ui.main.profile.ProfileFragment
import com.qrcard.app.ui.main.refer.ReferFragment
import com.qrcard.app.ui.main.transactions.TransactionsFragment
import com.qrcard.app.ui.main.wallet.WalletFragment
import com.qrcard.app.ui.main.work.WorkFragment

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        
        setupBottomNavigation()
        
        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(DashboardFragment())
            binding.bottomNavigation.selectedItemId = R.id.nav_dashboard
        }
    }
    
    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> {
                    loadFragment(DashboardFragment())
                    return@setOnItemSelectedListener true
                }
                R.id.nav_work -> {
                    loadFragment(WorkFragment())
                    return@setOnItemSelectedListener true
                }
                R.id.nav_wallet -> {
                    loadFragment(WalletFragment())
                    return@setOnItemSelectedListener true
                }
                R.id.nav_refer -> {
                    loadFragment(ReferFragment())
                    return@setOnItemSelectedListener true
                }
                R.id.nav_profile -> {
                    loadFragment(ProfileFragment())
                    return@setOnItemSelectedListener true
                }
                else -> false
            }
        }
    }
    
    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
