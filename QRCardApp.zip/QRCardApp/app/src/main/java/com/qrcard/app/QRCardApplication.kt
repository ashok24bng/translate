package com.qrcard.app

import android.app.Application
import com.google.firebase.FirebaseApp

class QRCardApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize Firebase
        FirebaseApp.initializeApp(this)
    }
}
