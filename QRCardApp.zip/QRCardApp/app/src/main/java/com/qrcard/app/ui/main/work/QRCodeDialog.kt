package com.qrcard.app.ui.main.work

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.google.gson.Gson
import com.qrcard.app.R
import com.qrcard.app.data.model.QRCode
import com.qrcard.app.databinding.DialogQrCodeBinding
import net.glxn.qrgen.android.QRCode

class QRCodeDialog : DialogFragment() {
    
    private var _binding: DialogQrCodeBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var qrCode: QRCode
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.Theme_QRCard_Dialog)
        
        arguments?.let {
            val qrCodeJson = it.getString(ARG_QR_CODE)
            qrCode = Gson().fromJson(qrCodeJson, QRCode::class.java)
        }
    }
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogQrCodeBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Generate QR code
        val qrCodeData = Gson().toJson(qrCode)
        val qrBitmap = QRCode.from(qrCodeData)
            .withSize(1000, 1000)
            .bitmap()
        
        binding.ivQrCode.setImageBitmap(qrBitmap)
        
        // Set QR code details
        binding.tvCompanyName.text = qrCode.companyName
        binding.tvBusinessId.text = qrCode.businessId
        binding.tvLocation.text = "${qrCode.city}, ${qrCode.country}"
        binding.tvEarnings.text = "₹${qrCode.earnings}"
        
        // Close button
        binding.btnClose.setOnClickListener {
            dismiss()
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        private const val ARG_QR_CODE = "qr_code"
        
        fun newInstance(qrCode: QRCode): QRCodeDialog {
            val fragment = QRCodeDialog()
            val args = Bundle()
            args.putString(ARG_QR_CODE, Gson().toJson(qrCode))
            fragment.arguments = args
            return fragment
        }
    }
}
