package com.qrcard.app.ui.main.work

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.qrcard.app.databinding.FragmentWorkBinding

class WorkFragment : Fragment() {
    
    private var _binding: FragmentWorkBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var viewModel: WorkViewModel
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWorkBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        viewModel = ViewModelProvider(this)[WorkViewModel::class.java]
        
        setupViews()
        observeViewModel()
    }
    
    private fun setupViews() {
        // Generate QR code button
        binding.btnGenerate.setOnClickListener {
            val companyName = binding.etCompanyName.text.toString().trim()
            val city = binding.etCity.text.toString().trim()
            val country = binding.etCountry.text.toString().trim()
            val zipCode = binding.etZipCode.text.toString().trim()
            val businessId = binding.etBusinessId.text.toString().trim()
            
            if (companyName.isEmpty() || city.isEmpty() || country.isEmpty() || 
                zipCode.isEmpty() || businessId.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            viewModel.generateQRCode(companyName, city, country, zipCode, businessId)
        }
        
        // Clear form button
        binding.btnClear.setOnClickListener {
            binding.etCompanyName.text?.clear()
            binding.etCity.text?.clear()
            binding.etCountry.text?.clear()
            binding.etZipCode.text?.clear()
            binding.etBusinessId.text?.clear()
        }
    }
    
    private fun observeViewModel() {
        // Observe loading state
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            binding.btnGenerate.isEnabled = !isLoading
            binding.btnClear.isEnabled = !isLoading
        }
        
        // Observe error messages
        viewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            if (errorMessage.isNotEmpty()) {
                Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_LONG).show()
            }
        }
        
        // Observe QR code generation success
        viewModel.qrCodeGenerated.observe(viewLifecycleOwner) { qrCode ->
            if (qrCode != null) {
                // Show QR code dialog
                QRCodeDialog.newInstance(qrCode).show(childFragmentManager, "QRCodeDialog")
                
                // Clear form
                binding.btnClear.performClick()
            }
        }
        
        // Observe daily limit
        viewModel.dailyQRCount.observe(viewLifecycleOwner) { count ->
            binding.tvDailyCount.text = "$count / ${viewModel.dailyLimit.value ?: 50}"
        }
        
        viewModel.dailyLimit.observe(viewLifecycleOwner) { limit ->
            binding.tvDailyCount.text = "${viewModel.dailyQRCount.value ?: 0} / $limit"
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
