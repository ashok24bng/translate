package com.qrcard.app.ui.main.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.qrcard.app.databinding.FragmentDashboardBinding
import com.qrcard.app.ui.auth.AuthActivity
import com.qrcard.app.ui.main.MainViewModel
import com.qrcard.app.ui.main.refer.ReferFragment
import com.qrcard.app.ui.main.wallet.WalletFragment
import com.qrcard.app.ui.main.work.WorkFragment

class DashboardFragment : Fragment() {
    
    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var viewModel: MainViewModel
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]
        
        setupViews()
        observeViewModel()
    }
    
    private fun setupViews() {
        // Quick action buttons
        binding.btnGenerateQr.setOnClickListener {
            navigateToFragment(WorkFragment())
        }
        
        binding.btnWithdraw.setOnClickListener {
            navigateToFragment(WalletFragment())
        }
        
        binding.btnShareEarn.setOnClickListener {
            navigateToFragment(ReferFragment())
        }
        
        binding.btnUpgradePlan.setOnClickListener {
            // TODO: Implement upgrade plan functionality
        }
        
        // Logout button
        binding.btnLogout.setOnClickListener {
            viewModel.logout()
            startActivity(Intent(requireContext(), AuthActivity::class.java))
            requireActivity().finish()
        }
    }
    
    private fun observeViewModel() {
        viewModel.userData.observe(viewLifecycleOwner) { user ->
            // Update user greeting
            binding.tvUserGreeting.text = user.fullName.split(" ")[0]
            
            // Update stats
            binding.tvTodayQrCount.text = "0" // This would need to be calculated
            binding.tvTotalQrCount.text = user.stats.qrCodesGenerated.toString()
            binding.tvTotalEarnings.text = "₹${user.wallet.earning}"
            
            // Update wallet balance
            binding.tvWalletBalance.text = "₹${user.wallet.balance}"
        }
        
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }
    
    private fun navigateToFragment(fragment: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(android.R.id.content, fragment)
            .addToBackStack(null)
            .commit()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
