package com.qrcard.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.qrcard.app.data.model.User
import kotlinx.coroutines.tasks.await

class UserRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    
    suspend fun getUserData(): User {
        val userId = auth.currentUser?.uid ?: throw Exception("User not logged in")
        val documentSnapshot = firestore.collection("users").document(userId).get().await()
        return documentSnapshot.toObject(User::class.java) ?: throw Exception("User data not found")
    }
    
    suspend fun updateUserProfile(fullName: String, phoneNumber: String, city: String): Boolean {
        val userId = auth.currentUser?.uid ?: throw Exception("User not logged in")
        
        firestore.collection("users").document(userId)
            .update(
                mapOf(
                    "fullName" to fullName,
                    "phoneNumber" to phoneNumber,
                    "city" to city
                )
            )
            .await()
        
        return true
    }
    
    suspend fun updateBankDetails(bank: String, account: String, ifsc: String, holder: String): Boolean {
        val userId = auth.currentUser?.uid ?: throw Exception("User not logged in")
        
        firestore.collection("users").document(userId)
            .update(
                mapOf(
                    "bankDetails.bank" to bank,
                    "bankDetails.account" to account,
                    "bankDetails.ifsc" to ifsc,
                    "bankDetails.holder" to holder
                )
            )
            .await()
        
        return true
    }
}
