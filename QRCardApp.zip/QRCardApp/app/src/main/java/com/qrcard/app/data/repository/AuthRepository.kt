package com.qrcard.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.qrcard.app.data.model.BankDetails
import com.qrcard.app.data.model.Plan
import com.qrcard.app.data.model.Stats
import com.qrcard.app.data.model.User
import com.qrcard.app.data.model.Wallet
import kotlinx.coroutines.tasks.await
import java.util.UUID

class AuthRepository {
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()
    
    val currentUser: FirebaseUser?
        get() = auth.currentUser
    
    suspend fun login(email: String, password: String): FirebaseUser {
        val authResult = auth.signInWithEmailAndPassword(email, password).await()
        return authResult.user ?: throw Exception("Login failed")
    }
    
    suspend fun register(
        fullName: String,
        email: String,
        password: String,
        phoneNumber: String,
        city: String,
        referredBy: String = ""
    ): FirebaseUser {
        val authResult = auth.createUserWithEmailAndPassword(email, password).await()
        val user = authResult.user ?: throw Exception("Registration failed")
        
        // Generate referral code
        val referralCode = generateReferralCode()
        
        // Create user document in Firestore
        val userData = User(
            id = user.uid,
            fullName = fullName,
            email = email,
            phoneNumber = phoneNumber,
            city = city,
            createdAt = System.currentTimeMillis().toString(),
            referralCode = referralCode,
            referredBy = referredBy,
            status = "active",
            wallet = Wallet(earning = 0.0, bonus = 0.0, balance = 0.0),
            plan = Plan(name = "Free Trial", dailyLimit = 50, rate = 5),
            stats = Stats(qrCodesGenerated = 0, totalScans = 0, totalEarnings = 0.0, referrals = 0),
            bankDetails = BankDetails()
        )
        
        firestore.collection("users").document(user.uid).set(userData).await()
        
        // If referred by someone, update their referrals count
        if (referredBy.isNotEmpty()) {
            try {
                val referrerQuery = firestore.collection("users")
                    .whereEqualTo("referralCode", referredBy)
                    .limit(1)
                    .get()
                    .await()
                
                if (!referrerQuery.isEmpty) {
                    val referrerId = referrerQuery.documents[0].id
                    firestore.collection("users").document(referrerId)
                        .update("stats.referrals", com.google.firebase.firestore.FieldValue.increment(1))
                        .await()
                }
            } catch (e: Exception) {
                // Ignore referral update errors
            }
        }
        
        return user
    }
    
    suspend fun getUserData(userId: String): User {
        val documentSnapshot = firestore.collection("users").document(userId).get().await()
        return documentSnapshot.toObject(User::class.java) ?: throw Exception("User data not found")
    }
    
    suspend fun updatePassword(currentPassword: String, newPassword: String) {
        val user = currentUser ?: throw Exception("User not logged in")
        val email = user.email ?: throw Exception("User email not found")
        
        // Re-authenticate user
        auth.signInWithEmailAndPassword(email, currentPassword).await()
        
        // Update password
        user.updatePassword(newPassword).await()
    }
    
    fun logout() {
        auth.signOut()
    }
    
    private fun generateReferralCode(): String {
        val allowedChars = ('A'..'Z') + ('0'..'9')
        return (1..6).map { allowedChars.random() }.joinToString("")
    }
}
