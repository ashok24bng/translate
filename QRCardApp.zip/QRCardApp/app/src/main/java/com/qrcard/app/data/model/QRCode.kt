package com.qrcard.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName

data class QRCode(
    @DocumentId
    val id: String = "",
    
    @PropertyName("userId")
    val userId: String = "",
    
    @PropertyName("companyName")
    val companyName: String = "",
    
    @PropertyName("city")
    val city: String = "",
    
    @PropertyName("country")
    val country: String = "",
    
    @PropertyName("zipCode")
    val zipCode: String = "",
    
    @PropertyName("businessId")
    val businessId: String = "",
    
    @PropertyName("timestamp")
    val timestamp: Timestamp = Timestamp.now(),
    
    @PropertyName("scanned")
    val scanned: Boolean = false,
    
    @PropertyName("earnings")
    val earnings: Double = 0.0
)
