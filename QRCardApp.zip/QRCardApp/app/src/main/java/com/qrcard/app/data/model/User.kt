package com.qrcard.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName
import java.util.Date

data class User(
    @DocumentId
    val id: String = "",
    
    @PropertyName("fullName")
    val fullName: String = "",
    
    @PropertyName("email")
    val email: String = "",
    
    @PropertyName("phoneNumber")
    val phoneNumber: String = "",
    
    @PropertyName("city")
    val city: String = "",
    
    @PropertyName("createdAt")
    val createdAt: String = "",
    
    @PropertyName("referralCode")
    val referralCode: String = "",
    
    @PropertyName("referredBy")
    val referredBy: String = "",
    
    @PropertyName("status")
    val status: String = "",
    
    @PropertyName("wallet")
    val wallet: Wallet = Wallet(),
    
    @PropertyName("plan")
    val plan: Plan = Plan(),
    
    @PropertyName("stats")
    val stats: Stats = Stats(),
    
    @PropertyName("bankDetails")
    val bankDetails: BankDetails = BankDetails()
)

data class Wallet(
    @PropertyName("earning")
    val earning: Double = 0.0,
    
    @PropertyName("bonus")
    val bonus: Double = 0.0,
    
    @PropertyName("balance")
    val balance: Double = 0.0
)

data class Plan(
    @PropertyName("name")
    val name: String = "",
    
    @PropertyName("dailyLimit")
    val dailyLimit: Int = 0,
    
    @PropertyName("rate")
    val rate: Int = 0
)

data class Stats(
    @PropertyName("qrCodesGenerated")
    val qrCodesGenerated: Int = 0,
    
    @PropertyName("totalScans")
    val totalScans: Int = 0,
    
    @PropertyName("totalEarnings")
    val totalEarnings: Double = 0.0,
    
    @PropertyName("referrals")
    val referrals: Int = 0
)

data class BankDetails(
    @PropertyName("bank")
    val bank: String = "",
    
    @PropertyName("account")
    val account: String = "",
    
    @PropertyName("ifsc")
    val ifsc: String = "",
    
    @PropertyName("holder")
    val holder: String = ""
)
