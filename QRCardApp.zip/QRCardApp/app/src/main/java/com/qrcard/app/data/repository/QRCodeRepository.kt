package com.qrcard.app.data.repository

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.qrcard.app.data.model.QRCode
import com.qrcard.app.data.model.User
import kotlinx.coroutines.tasks.await
import java.util.Calendar
import java.util.Date

class QRCodeRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    
    suspend fun generateQRCode(
        companyName: String,
        city: String,
        country: String,
        zipCode: String,
        businessId: String
    ): QRCode {
        val userId = auth.currentUser?.uid ?: throw Exception("User not logged in")
        
        // Get user data to check daily limit
        val userDoc = firestore.collection("users").document(userId).get().await()
        val user = userDoc.toObject(User::class.java) ?: throw Exception("User data not found")
        
        // Check if user has reached daily limit
        val todayQRCount = getTodayQRCodesCount(userId)
        if (todayQRCount >= user.plan.dailyLimit) {
            throw Exception("You have reached your daily limit of ${user.plan.dailyLimit} QR codes")
        }
        
        // Create QR code document
        val qrCode = QRCode(
            userId = userId,
            companyName = companyName,
            city = city,
            country = country,
            zipCode = zipCode,
            businessId = businessId,
            timestamp = Timestamp.now(),
            scanned = false,
            earnings = user.plan.rate.toDouble()
        )
        
        // Add to Firestore
        val docRef = firestore.collection("qrcodes").add(qrCode).await()
        
        // Update user stats
        firestore.collection("users").document(userId)
            .update(
                "stats.qrCodesGenerated", com.google.firebase.firestore.FieldValue.increment(1),
                "wallet.earning", com.google.firebase.firestore.FieldValue.increment(user.plan.rate.toDouble()),
                "wallet.balance", com.google.firebase.firestore.FieldValue.increment(user.plan.rate.toDouble())
            )
            .await()
        
        return qrCode.copy(id = docRef.id)
    }
    
    suspend fun getTodayQRCodesCount(userId: String): Int {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        
        val startOfDay = calendar.time
        
        val query = firestore.collection("qrcodes")
            .whereEqualTo("userId", userId)
            .whereGreaterThanOrEqualTo("timestamp", Timestamp(startOfDay))
            .get()
            .await()
        
        return query.size()
    }
    
    suspend fun getQRCodeHistory(userId: String, limit: Long = 50): List<QRCode> {
        val query = firestore.collection("qrcodes")
            .whereEqualTo("userId", userId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
        
        return query.documents.mapNotNull { it.toObject(QRCode::class.java) }
    }
}
