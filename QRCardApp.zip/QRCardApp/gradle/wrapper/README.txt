You need to download the gradle-wrapper.jar file and place it in this directory.
You can download it from: https://github.com/gradle/gradle/raw/v7.6.0/gradle/wrapper/gradle-wrapper.jar
