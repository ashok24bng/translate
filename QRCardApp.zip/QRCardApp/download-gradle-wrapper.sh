#!/bin/bash
echo "Downloading Gradle Wrapper JAR file..."
mkdir -p gradle/wrapper
curl -L "https://github.com/gradle/gradle/raw/v7.6.0/gradle/wrapper/gradle-wrapper.jar" -o "gradle/wrapper/gradle-wrapper.jar"
echo "Download complete!"
echo "The Gradle Wrapper JAR file has been saved to gradle/wrapper/gradle-wrapper.jar"
